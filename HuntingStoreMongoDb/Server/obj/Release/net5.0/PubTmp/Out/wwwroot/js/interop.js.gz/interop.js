﻿
function ShowMessageModal() {

    $("#messageModal").modal("show");
}

function HideMessageModal() {

    $("#messageModal").modal("hide");
}

function TestMethod() {
    alert("test");
}